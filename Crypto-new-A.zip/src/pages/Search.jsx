import React from 'react'
import SearchList from '../component/serach/SearchList'

const Search = () => {
    return (
        <section className=" w-full flex justify-center">
            <SearchList />
        </section>

    )
}

export default Search